/* Copyright 2020 */


/*Returns the least value of first and second int parameters.
 */
int Min(int first, int second);

/*Returns the least value of first and second double parameters.
 */
double Min(double first, double second);

/*Returns the least value of first and second char parameters.
 */
char Min(char first, char second);
