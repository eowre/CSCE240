/* Copyright 2020 */



/*Tests correct functionality of Min functions
 */
int main(int argc, char* argv[]) {
  return 0;
}
