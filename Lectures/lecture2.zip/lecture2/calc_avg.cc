/* calc_avg.cc copyright 2020
 * 
 * Given a file (using IO redirect) which begins with a single integer n, and
 * contains n whitespace-delimited doubles, calculate the mean of the doubles.
 * Use io redirect. 
 */


int main(int argc, char* argv[]) {

  return 0;
}
