/* Copyright 2020
 *
 * This is a rational file parser. I will open a specified file and expects a
 * file format of n num den num den num den..., where there are n num
 * den pairs. All values are integers.
 *
 * The values are printed to the terminal as num/den, one per line.
 */


int main(int argc, char* argv[]) {
  // check number of arguments, give usage message if missing file name
  
  // use filename from argument list to open filestream
  
  // ensure file is open, return 2 if not
  
  // ensure file is not empty, return 3 for corrupt/empty file
  
  // get number of rationals
  
  // ensure data actually exists
  
  // loop over rationals
  
    // ensure data exists before reads and print each rational

  return 0;
}
