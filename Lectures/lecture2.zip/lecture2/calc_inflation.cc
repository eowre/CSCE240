/* calc_inflation.cc copyright 2020
 * 
 * Due to inflation, the cost of goods increase over the years in which they
 * must be purchased. Write an app which given the cost of a good, the expected
 * annual rate of inflation (as a percentage), and number of years, display the
 * increasing cost, year-by-year, line-by-line.
 */

int main(int argc, char* argv[]) {

  return 0;
}
