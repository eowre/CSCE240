/* calc_prime.cc copyright 2020
 * 
 * Write a program that prints on a single line, separated but not terminated by
 * commas, all prime numbers [3, 100).
 *
 * Now, update the app to accept a lower bound and upper bound from user input
 * and, so long as 2 < lower_bound < upper_bound, display all prime numbers
 * from [lower_bound, upper_bound]
 */


int main(int argc, char* argv[]) {
  // get upper and lower bound from user and ensure constraints

  // calculate greatest prime for printing

  // calculate and print primes in [lower, upper] s.t. upper < greatest_prime

  // print greatest prime value

  return 0;
}
