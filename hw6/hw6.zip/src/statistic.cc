/* Copyright 2020 Evan Owre 
 */
#include <inc/statistic.h>

