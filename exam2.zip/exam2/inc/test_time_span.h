/* Copyright 2020 CSCE 240
 */


#include <inc/time_span.h>
#include <cassert>
// using assert
#include <cstdlib>
// using atoi
#include <iostream>
#include <sstream>
#include <string>


bool TestOperatorPlusTimeSpan();
bool TestOperatorPlusInt();
bool TestOperatorExtract();
bool TestOperatorInsert();
